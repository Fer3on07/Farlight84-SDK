// BlueprintGeneratedClass ChaGCBP_SkywardDiveLaunch.ChaGCBP_SkywardDiveLaunch_C
// Size: 0x2d8 (Inherited: 0x2d0)
struct AChaGCBP_SkywardDiveLaunch_C : AChaGC_SkywardDiveLaunch {
	struct USceneComponent* DefaultSceneRoot; // 0x2d0(0x08)
};

