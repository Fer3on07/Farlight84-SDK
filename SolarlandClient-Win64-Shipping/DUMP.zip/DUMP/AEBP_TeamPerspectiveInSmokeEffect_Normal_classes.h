// BlueprintGeneratedClass AEBP_TeamPerspectiveInSmokeEffect_Normal.AEBP_TeamPerspectiveInSmokeEffect_Normal_C
// Size: 0x1c0 (Inherited: 0x1c0)
struct UAEBP_TeamPerspectiveInSmokeEffect_Normal_C : UMaterialSimpleEffect {
};

