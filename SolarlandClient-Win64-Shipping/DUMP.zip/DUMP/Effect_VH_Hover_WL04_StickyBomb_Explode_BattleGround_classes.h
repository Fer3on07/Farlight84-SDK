// BlueprintGeneratedClass Effect_VH_Hover_WL04_StickyBomb_Explode_BattleGround.Effect_VH_Hover_WL04_StickyBomb_Explode_BattleGround_C
// Size: 0x198 (Inherited: 0x198)
struct UEffect_VH_Hover_WL04_StickyBomb_Explode_BattleGround_C : UEffect_VH_Hover_WL04_StickyBomb_Explode_C {
};

