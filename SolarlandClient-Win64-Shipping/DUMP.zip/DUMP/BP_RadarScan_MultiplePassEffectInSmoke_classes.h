// BlueprintGeneratedClass BP_RadarScan_MultiplePassEffectInSmoke.BP_RadarScan_MultiplePassEffectInSmoke_C
// Size: 0x1c8 (Inherited: 0x1c8)
struct UBP_RadarScan_MultiplePassEffectInSmoke_C : UMultiplePassMaterialEffect {
};

