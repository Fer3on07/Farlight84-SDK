// BlueprintGeneratedClass Ability_VH_Tire_Mphy01_TurretB1_Rocket_ExplosionDamage_man.Ability_VH_Tire_Mphy01_TurretB1_Rocket_ExplosionDamage_man_C
// Size: 0x319 (Inherited: 0x310)
struct AAbility_VH_Tire_Mphy01_TurretB1_Rocket_ExplosionDamage_man_C : ASolarAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x310(0x08)
	bool HasExploded; // 0x318(0x01)

	void ReceiveBeginPlay(); // Function Ability_VH_Tire_Mphy01_TurretB1_Rocket_ExplosionDamage_man.Ability_VH_Tire_Mphy01_TurretB1_Rocket_ExplosionDamage_man_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x2d0f120
	void ReceiveTick(float DeltaSeconds); // Function Ability_VH_Tire_Mphy01_TurretB1_Rocket_ExplosionDamage_man.Ability_VH_Tire_Mphy01_TurretB1_Rocket_ExplosionDamage_man_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x2d0f120
	void ExecuteUbergraph_Ability_VH_Tire_Mphy01_TurretB1_Rocket_ExplosionDamage_man(int32_t EntryPoint); // Function Ability_VH_Tire_Mphy01_TurretB1_Rocket_ExplosionDamage_man.Ability_VH_Tire_Mphy01_TurretB1_Rocket_ExplosionDamage_man_C.ExecuteUbergraph_Ability_VH_Tire_Mphy01_TurretB1_Rocket_ExplosionDamage_man // (Final|UbergraphFunction) // @ game+0x2d0f120
};

