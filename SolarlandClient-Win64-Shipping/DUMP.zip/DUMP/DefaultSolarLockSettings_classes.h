// BlueprintGeneratedClass DefaultSolarLockSettings.DefaultSolarLockSettings_C
// Size: 0x78 (Inherited: 0x78)
struct UDefaultSolarLockSettings_C : USolarLockSettings {
};

