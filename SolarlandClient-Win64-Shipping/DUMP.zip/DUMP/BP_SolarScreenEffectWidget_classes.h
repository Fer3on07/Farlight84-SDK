// WidgetBlueprintGeneratedClass BP_SolarScreenEffectWidget.BP_SolarScreenEffectWidget_C
// Size: 0x408 (Inherited: 0x408)
struct UBP_SolarScreenEffectWidget_C : USolarScreenEffectWidget {

	void FadeOutScreenEffect(); // Function BP_SolarScreenEffectWidget.BP_SolarScreenEffectWidget_C.FadeOutScreenEffect // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2d0f120
	bool IsFadeOutFinished(); // Function BP_SolarScreenEffectWidget.BP_SolarScreenEffectWidget_C.IsFadeOutFinished // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2d0f120
	bool IsInstantEffectComplete(); // Function BP_SolarScreenEffectWidget.BP_SolarScreenEffectWidget_C.IsInstantEffectComplete // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2d0f120
};

