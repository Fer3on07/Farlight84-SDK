// BlueprintGeneratedClass BP_MassInvisibilityStealthEffect.BP_MassInvisibilityStealthEffect_C
// Size: 0x1c0 (Inherited: 0x1c0)
struct UBP_MassInvisibilityStealthEffect_C : UMaterialSimpleEffect {
};

