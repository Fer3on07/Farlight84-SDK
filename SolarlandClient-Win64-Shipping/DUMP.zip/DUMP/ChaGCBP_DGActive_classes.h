// BlueprintGeneratedClass ChaGCBP_DGActive.ChaGCBP_DGActive_C
// Size: 0x478 (Inherited: 0x470)
struct AChaGCBP_DGActive_C : AChaGC_DoppelgangerActive {
	struct USceneComponent* DefaultSceneRoot; // 0x470(0x08)
};

