// BlueprintGeneratedClass ChaGCBP_SummonTowerHoldEar.ChaGCBP_SummonTowerHoldEar_C
// Size: 0x308 (Inherited: 0x300)
struct AChaGCBP_SummonTowerHoldEar_C : AChaGC_SummonTowerHoldEar {
	struct USceneComponent* DefaultSceneRoot; // 0x300(0x08)
};

