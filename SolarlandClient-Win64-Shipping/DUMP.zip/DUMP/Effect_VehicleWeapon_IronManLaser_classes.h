// BlueprintGeneratedClass Effect_VehicleWeapon_IronManLaser.Effect_VehicleWeapon_IronManLaser_C
// Size: 0x198 (Inherited: 0x198)
struct UEffect_VehicleWeapon_IronManLaser_C : USolarAbilityEffect {
};

