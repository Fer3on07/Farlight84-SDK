// BlueprintGeneratedClass GA_Fireworks.GA_Fireworks_C
// Size: 0x4f0 (Inherited: 0x4f0)
struct UGA_Fireworks_C : USolarVehicleGameplayAbility {
};

