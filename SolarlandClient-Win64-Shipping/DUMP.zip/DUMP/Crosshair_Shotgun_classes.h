// WidgetBlueprintGeneratedClass Crosshair_Shotgun.Crosshair_Shotgun_C
// Size: 0x315 (Inherited: 0x300)
struct UCrosshair_Shotgun_C : UCrossHairWidget {
	struct UImage* SpreadImg_Leftarrow; // 0x300(0x08)
	struct UImage* SpreadImg_Rightarrow; // 0x308(0x08)
	int32_t  �� ; // 0x310(0x04)
	enum class E_UI_Bullet_Type  �� ; // 0x314(0x01)

	struct UUserWidget* GetAmmoWidget(); // Function Crosshair_Shotgun.Crosshair_Shotgun_C.GetAmmoWidget // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2d0f120
	struct UUserWidget* GetReloadWidget(); // Function Crosshair_Shotgun.Crosshair_Shotgun_C.GetReloadWidget // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2d0f120
};

