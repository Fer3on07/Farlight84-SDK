// BlueprintGeneratedClass BP_DissolvedDeath.BP_DissolvedDeath_C
// Size: 0x1d0 (Inherited: 0x1d0)
struct UBP_DissolvedDeath_C : UMaterialVariableEffect {
};

