// BlueprintGeneratedClass BP_InvisibilityZoneController.BP_InvisibilityZoneController_C
// Size: 0x40 (Inherited: 0x40)
struct UBP_InvisibilityZoneController_C : UTimedEffectController {
};

