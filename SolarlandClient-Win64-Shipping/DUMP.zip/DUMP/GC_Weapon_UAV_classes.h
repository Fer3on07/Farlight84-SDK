// BlueprintGeneratedClass GC_Weapon_UAV.GC_Weapon_UAV_C
// Size: 0x58 (Inherited: 0x50)
struct UGC_Weapon_UAV_C : UGameplayCueNotify_Static {
	struct UParticleSystem* ParticleEffect; // 0x50(0x08)

	bool OnActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters); // Function GC_Weapon_UAV.GC_Weapon_UAV_C.OnActive // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x2d0f120
};

