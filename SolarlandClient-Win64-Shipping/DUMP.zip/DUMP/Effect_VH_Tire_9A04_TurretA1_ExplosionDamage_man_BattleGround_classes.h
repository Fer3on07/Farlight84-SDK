// BlueprintGeneratedClass Effect_VH_Tire_9A04_TurretA1_ExplosionDamage_man_BattleGround.Effect_VH_Tire_9A04_TurretA1_ExplosionDamage_man_BattleGround_C
// Size: 0x198 (Inherited: 0x198)
struct UEffect_VH_Tire_9A04_TurretA1_ExplosionDamage_man_BattleGround_C : UEffect_VH_Tire_9A04_TurretA1_ExplosionDamage_man_C {
};

