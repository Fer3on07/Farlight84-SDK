// BlueprintGeneratedClass BP_SettlementStageMgr.BP_SettlementStageMgr_C
// Size: 0x50 (Inherited: 0x50)
struct UBP_SettlementStageMgr_C : USettlementStageManager {

	void SkipToTarget(); // Function BP_SettlementStageMgr.BP_SettlementStageMgr_C.SkipToTarget // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xb67940
	void ShowDiePage(); // Function BP_SettlementStageMgr.BP_SettlementStageMgr_C.ShowDiePage // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xb67940
	void CloseDiePage(); // Function BP_SettlementStageMgr.BP_SettlementStageMgr_C.CloseDiePage // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xb67940
	struct FString GetClassRelativePathName(struct UObject* InClass); // Function BP_SettlementStageMgr.BP_SettlementStageMgr_C.GetClassRelativePathName // (Event|Public|BlueprintEvent) // @ game+0xb67940
	void Init(); // Function BP_SettlementStageMgr.BP_SettlementStageMgr_C.Init // (Event|Public|BlueprintEvent) // @ game+0xb67940
	void ShowNextStage(); // Function BP_SettlementStageMgr.BP_SettlementStageMgr_C.ShowNextStage // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0xb67940
};

