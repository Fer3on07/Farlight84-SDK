// BlueprintGeneratedClass BP_WL03_DissolvedDeath.BP_WL03_DissolvedDeath_C
// Size: 0x1d0 (Inherited: 0x1d0)
struct UBP_WL03_DissolvedDeath_C : UMaterialVariableEffect {
};

