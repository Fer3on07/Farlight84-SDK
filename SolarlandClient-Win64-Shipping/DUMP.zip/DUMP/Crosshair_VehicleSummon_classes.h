// WidgetBlueprintGeneratedClass Crosshair_VehicleSummon.Crosshair_VehicleSummon_C
// Size: 0x328 (Inherited: 0x300)
struct UCrosshair_VehicleSummon_C : UCrossHairWidget {
	struct UImage* SpreadImg_coredot; // 0x300(0x08)
	struct UImage* SpreadImg_Downarrow; // 0x308(0x08)
	struct UImage* SpreadImg_Leftarrow; // 0x310(0x08)
	struct UImage* SpreadImg_Rightarrow; // 0x318(0x08)
	struct UImage* SpreadImg_uparrow; // 0x320(0x08)
};

