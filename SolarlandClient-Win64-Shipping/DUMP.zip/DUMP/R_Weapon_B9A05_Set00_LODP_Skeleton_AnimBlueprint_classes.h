// DynamicClass R_Weapon_B9A05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A05_Set00_LODP_Skeleton_AnimBlueprint_C
// Size: 0x360 (Inherited: 0x2d0)
struct UR_Weapon_B9A05_Set00_LODP_Skeleton_AnimBlueprint_C : UWeaponAnimInstance {
	struct FAnimNode_Root AnimGraphNode_Root; // 0x2d0(0x30)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x300(0x48)
	struct FAnimNode_RefPose AnimGraphNode_LocalRefPose; // 0x348(0x18)

	void ExecuteUbergraph_R_Weapon_B9A05_Set00_LODP_Skeleton_AnimBlueprint(int32_t bpp__EntryPoint__pf); // Function R_Weapon_B9A05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A05_Set00_LODP_Skeleton_AnimBlueprint_C.ExecuteUbergraph_R_Weapon_B9A05_Set00_LODP_Skeleton_AnimBlueprint // (Final|Native|Public) // @ game+0x1ae69a0
	void AnimGraph(struct FPoseLink& bpp__AnimGraph__pf); // Function R_Weapon_B9A05_Set00_LODP_Skeleton_AnimBlueprint.R_Weapon_B9A05_Set00_LODP_Skeleton_AnimBlueprint_C.AnimGraph // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x1ae4420
};

