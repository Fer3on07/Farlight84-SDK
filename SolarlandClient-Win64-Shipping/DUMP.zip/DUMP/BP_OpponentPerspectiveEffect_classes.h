// BlueprintGeneratedClass BP_OpponentPerspectiveEffect.BP_OpponentPerspectiveEffect_C
// Size: 0x1c8 (Inherited: 0x1c8)
struct UBP_OpponentPerspectiveEffect_C : UMultiplePassMaterialEffect {
};

