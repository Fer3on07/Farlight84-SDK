// BlueprintGeneratedClass ChaGCBP_DGExposeEnemy.ChaGCBP_DGExposeEnemy_C
// Size: 0x2e0 (Inherited: 0x2d8)
struct AChaGCBP_DGExposeEnemy_C : AChaGC_DoppelgangerExposeEnemy {
	struct USceneComponent* DefaultSceneRoot; // 0x2d8(0x08)
};

