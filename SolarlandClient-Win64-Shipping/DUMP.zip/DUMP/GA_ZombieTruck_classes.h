// BlueprintGeneratedClass GA_ZombieTruck.GA_ZombieTruck_C
// Size: 0x500 (Inherited: 0x4f8)
struct UGA_ZombieTruck_C : USolarVehicleGA_ZombieTruck {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4f8(0x08)

	void K2_OnEndAbility(bool bWasCancelled); // Function GA_ZombieTruck.GA_ZombieTruck_C.K2_OnEndAbility // (Event|Protected|BlueprintEvent) // @ game+0x2d0f120
	void K2_CommitExecute(); // Function GA_ZombieTruck.GA_ZombieTruck_C.K2_CommitExecute // (Event|Public|BlueprintEvent) // @ game+0x2d0f120
	void ExecuteUbergraph_GA_ZombieTruck(int32_t EntryPoint); // Function GA_ZombieTruck.GA_ZombieTruck_C.ExecuteUbergraph_GA_ZombieTruck // (Final|UbergraphFunction|HasDefaults) // @ game+0x2d0f120
};

