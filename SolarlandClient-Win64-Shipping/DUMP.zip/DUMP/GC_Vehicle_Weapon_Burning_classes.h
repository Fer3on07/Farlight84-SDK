// BlueprintGeneratedClass GC_Vehicle_Weapon_Burning.GC_Vehicle_Weapon_Burning_C
// Size: 0x300 (Inherited: 0x2f8)
struct AGC_Vehicle_Weapon_Burning_C : ASolarVehicleGC_Burning {
	struct USceneComponent* DefaultSceneRoot; // 0x2f8(0x08)
};

