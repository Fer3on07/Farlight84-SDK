// BlueprintGeneratedClass ChaGEBP_DuckRollingEnableCharacterHit.ChaGEBP_DuckRollingEnableCharacterHit_C
// Size: 0x848 (Inherited: 0x848)
struct UChaGEBP_DuckRollingEnableCharacterHit_C : UGameplayEffect {
};

