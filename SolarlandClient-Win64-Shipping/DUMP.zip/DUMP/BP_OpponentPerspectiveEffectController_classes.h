// BlueprintGeneratedClass BP_OpponentPerspectiveEffectController.BP_OpponentPerspectiveEffectController_C
// Size: 0x270 (Inherited: 0x270)
struct UBP_OpponentPerspectiveEffectController_C : UOpponentPerspectiveEffectController {
};

