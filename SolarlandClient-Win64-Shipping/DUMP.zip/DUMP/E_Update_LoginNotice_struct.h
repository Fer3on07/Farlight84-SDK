// UserDefinedEnum E_Update_LoginNotice.E_Update_LoginNotice
enum class E_Update_LoginNotice : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	E_Update_MAX = 2
};

