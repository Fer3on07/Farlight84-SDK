// BlueprintGeneratedClass BP_Mphy01_QuickSummon_Forward.BP_Mphy01_QuickSummon_Forward_C
// Size: 0x40 (Inherited: 0x40)
struct UBP_Mphy01_QuickSummon_Forward_C : UBP_QuickSummon_Forward_C {
};

