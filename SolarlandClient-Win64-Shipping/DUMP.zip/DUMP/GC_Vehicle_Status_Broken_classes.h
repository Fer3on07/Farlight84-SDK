// BlueprintGeneratedClass GC_Vehicle_Status_Broken.GC_Vehicle_Status_Broken_C
// Size: 0x50 (Inherited: 0x50)
struct UGC_Vehicle_Status_Broken_C : UGameplayCueNotify_Static {

	bool OnActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters); // Function GC_Vehicle_Status_Broken.GC_Vehicle_Status_Broken_C.OnActive // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x2d0f120
	bool WhileActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters); // Function GC_Vehicle_Status_Broken.GC_Vehicle_Status_Broken_C.WhileActive // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x2d0f120
};

