// BlueprintGeneratedClass BP_FreezeMatEffect.BP_FreezeMatEffect_C
// Size: 0x1c0 (Inherited: 0x1c0)
struct UBP_FreezeMatEffect_C : UMaterialSimpleEffect {
};

