// WidgetBlueprintGeneratedClass HUD_CarFireCD.HUD_CarFireCD_C
// Size: 0x418 (Inherited: 0x418)
struct UHUD_CarFireCD_C : USolarWeaponRechamberWidget {
};

