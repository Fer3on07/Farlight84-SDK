// BlueprintGeneratedClass ChaGCBP_ParkourHoriAcc.ChaGCBP_ParkourHoriAcc_C
// Size: 0x2b8 (Inherited: 0x2b0)
struct AChaGCBP_ParkourHoriAcc_C : AChaGC_CharacterActorCueBase {
	struct USceneComponent* DefaultSceneRoot; // 0x2b0(0x08)
};

