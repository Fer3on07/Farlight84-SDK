// BlueprintGeneratedClass ChaGCBP_SkywardDivePrepare.ChaGCBP_SkywardDivePrepare_C
// Size: 0x2d0 (Inherited: 0x2c8)
struct AChaGCBP_SkywardDivePrepare_C : AChaGC_SkywardDivePrepare {
	struct USceneComponent* DefaultSceneRoot; // 0x2c8(0x08)
};

