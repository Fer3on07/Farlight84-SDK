// BlueprintGeneratedClass BP_Weapon_EMP_Throw.BP_Weapon_EMP_Throw_C
// Size: 0x690 (Inherited: 0x690)
struct ABP_Weapon_EMP_Throw_C : ASolarSkill_EMP {
};

