// BlueprintGeneratedClass Ability_VH_Leg_9A02_Gatling_BaseDamage.Ability_VH_Leg_9A02_Gatling_BaseDamage_C
// Size: 0x310 (Inherited: 0x310)
struct AAbility_VH_Leg_9A02_Gatling_BaseDamage_C : ASolarAbility {
};

