// BlueprintGeneratedClass ChaGCBP_MeleeAttack.ChaGCBP_MeleeAttack_C
// Size: 0x50 (Inherited: 0x50)
struct UChaGCBP_MeleeAttack_C : UGameplayCueNotify_Static {

	bool OnExecute(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters); // Function ChaGCBP_MeleeAttack.ChaGCBP_MeleeAttack_C.OnExecute // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x2d0f120
};

