// BlueprintGeneratedClass B_DuckRollingMeshComponent.B_DuckRollingMeshComponent_C
// Size: 0xcf0 (Inherited: 0xce0)
struct UB_DuckRollingMeshComponent_C : UDuckRollingMeshComponent {
	struct TArray<struct UAnimMontage*> JumpPoseMontages; // 0xce0(0x10)
};

