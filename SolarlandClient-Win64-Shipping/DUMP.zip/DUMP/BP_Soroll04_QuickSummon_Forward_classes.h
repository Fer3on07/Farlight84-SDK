// BlueprintGeneratedClass BP_Soroll04_QuickSummon_Forward.BP_Soroll04_QuickSummon_Forward_C
// Size: 0x40 (Inherited: 0x40)
struct UBP_Soroll04_QuickSummon_Forward_C : UBP_QuickSummon_Forward_C {
};

