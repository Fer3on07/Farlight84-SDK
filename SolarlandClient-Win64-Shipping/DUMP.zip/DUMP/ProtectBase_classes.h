// Class ProtectBase.ProtectBaseComponent
// Size: 0x70 (Inherited: 0x28)
struct UProtectBaseComponent : UObject {
	char pad_28[0x48]; // 0x28(0x48)

	struct UProtectBaseComponent* GetInstance(); // Function ProtectBase.ProtectBaseComponent.GetInstance // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xcbb140
};

// Class ProtectBase.ProtectBaseManager
// Size: 0x28 (Inherited: 0x28)
struct UProtectBaseManager : UObject {
};

// Class ProtectBase.SecDSComponent
// Size: 0xc0 (Inherited: 0x28)
struct USecDSComponent : UObject {
	char pad_28[0x98]; // 0x28(0x98)

	struct USecDSComponent* GetInstance(); // Function ProtectBase.SecDSComponent.GetInstance // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xcbb170
};

