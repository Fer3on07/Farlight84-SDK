// BlueprintGeneratedClass ChaGCBP_BlinkAppear.ChaGCBP_BlinkAppear_C
// Size: 0x88 (Inherited: 0x88)
struct UChaGCBP_BlinkAppear_C : UChaGC_BlinkAppear {
};

