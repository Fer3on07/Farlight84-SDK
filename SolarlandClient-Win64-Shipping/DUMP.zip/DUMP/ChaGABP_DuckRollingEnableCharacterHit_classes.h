// BlueprintGeneratedClass ChaGABP_DuckRollingEnableCharacterHit.ChaGABP_DuckRollingEnableCharacterHit_C
// Size: 0x460 (Inherited: 0x460)
struct UChaGABP_DuckRollingEnableCharacterHit_C : USolarCharacterGameplayAbility_Blueprint {
};

