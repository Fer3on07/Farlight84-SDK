// BlueprintGeneratedClass ChaGCBP_MassInvisibility.ChaGCBP_MassInvisibility_C
// Size: 0x370 (Inherited: 0x368)
struct AChaGCBP_MassInvisibility_C : AChaGC_MassInvisibility {
	struct USceneComponent* DefaultSceneRoot; // 0x368(0x08)
};

