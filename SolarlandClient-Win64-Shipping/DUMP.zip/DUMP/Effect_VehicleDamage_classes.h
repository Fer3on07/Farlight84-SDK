// BlueprintGeneratedClass Effect_VehicleDamage.Effect_VehicleDamage_C
// Size: 0x198 (Inherited: 0x198)
struct UEffect_VehicleDamage_C : USolarAbilityEffect {
};

