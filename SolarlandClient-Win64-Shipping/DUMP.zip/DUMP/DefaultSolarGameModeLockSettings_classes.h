// BlueprintGeneratedClass DefaultSolarGameModeLockSettings.DefaultSolarGameModeLockSettings_C
// Size: 0x98 (Inherited: 0x98)
struct UDefaultSolarGameModeLockSettings_C : USolarGameModeLockSettings {
};

