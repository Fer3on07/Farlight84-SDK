// BlueprintGeneratedClass ChaGCBP_RescueSuccceed.ChaGCBP_RescueSuccceed_C
// Size: 0x2a0 (Inherited: 0x298)
struct AChaGCBP_RescueSuccceed_C : AGameplayCueNotify_Actor {
	struct USceneComponent* DefaultSceneRoot; // 0x298(0x08)

	bool OnRemove(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters); // Function ChaGCBP_RescueSuccceed.ChaGCBP_RescueSuccceed_C.OnRemove // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2d0f120
	bool OnActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters); // Function ChaGCBP_RescueSuccceed.ChaGCBP_RescueSuccceed_C.OnActive // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2d0f120
};

