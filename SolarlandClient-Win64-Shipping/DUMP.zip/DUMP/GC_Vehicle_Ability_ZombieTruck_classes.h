// BlueprintGeneratedClass GC_Vehicle_Ability_ZombieTruck.GC_Vehicle_Ability_ZombieTruck_C
// Size: 0x50 (Inherited: 0x50)
struct UGC_Vehicle_Ability_ZombieTruck_C : USolarVehicleGC_ZombieTruck {

	bool OnRemove(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters); // Function GC_Vehicle_Ability_ZombieTruck.GC_Vehicle_Ability_ZombieTruck_C.OnRemove // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x2d0f120
	bool WhileActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters); // Function GC_Vehicle_Ability_ZombieTruck.GC_Vehicle_Ability_ZombieTruck_C.WhileActive // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x2d0f120
};

