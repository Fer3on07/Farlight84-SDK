// BlueprintGeneratedClass Effect_VH_Hover_Soroll05_weapon_ExplosionDamage_Secondary.Effect_VH_Hover_Soroll05_weapon_ExplosionDamage_Secondary_C
// Size: 0x198 (Inherited: 0x198)
struct UEffect_VH_Hover_Soroll05_weapon_ExplosionDamage_Secondary_C : USolarAbilityEffect {
};

