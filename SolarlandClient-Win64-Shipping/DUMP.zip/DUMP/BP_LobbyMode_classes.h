// BlueprintGeneratedClass BP_LobbyMode.BP_LobbyMode_C
// Size: 0x2d0 (Inherited: 0x2c8)
struct ABP_LobbyMode_C : AGameModeBase {
	struct USceneComponent* DefaultSceneRoot; // 0x2c8(0x08)
};

