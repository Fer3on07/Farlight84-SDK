// BlueprintGeneratedClass BP_WL03_RotationAnim.BP_WL03_RotationAnim_C
// Size: 0x160 (Inherited: 0x160)
struct UBP_WL03_RotationAnim_C : UCameraShake {
};

