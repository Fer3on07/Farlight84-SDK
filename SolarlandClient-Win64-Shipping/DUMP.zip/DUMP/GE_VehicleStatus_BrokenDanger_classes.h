// BlueprintGeneratedClass GE_VehicleStatus_BrokenDanger.GE_VehicleStatus_BrokenDanger_C
// Size: 0x848 (Inherited: 0x848)
struct UGE_VehicleStatus_BrokenDanger_C : UGameplayEffect {
};

