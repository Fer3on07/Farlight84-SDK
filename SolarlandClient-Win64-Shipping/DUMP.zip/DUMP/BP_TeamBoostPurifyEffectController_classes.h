// BlueprintGeneratedClass BP_TeamBoostPurifyEffectController.BP_TeamBoostPurifyEffectController_C
// Size: 0x40 (Inherited: 0x40)
struct UBP_TeamBoostPurifyEffectController_C : UTimedEffectController {
};

