// BlueprintGeneratedClass ChaGCBP_TeamBoost.ChaGCBP_TeamBoost_C
// Size: 0x2c0 (Inherited: 0x2b8)
struct AChaGCBP_TeamBoost_C : AChaGC_SuperSkillActorCueBase {
	struct USceneComponent* DefaultSceneRoot; // 0x2b8(0x08)
};

