// BlueprintGeneratedClass Effect_VH_Leg_WL09_Rocket_ExplosionDamage.Effect_VH_Leg_WL09_Rocket_ExplosionDamage_C
// Size: 0x198 (Inherited: 0x198)
struct UEffect_VH_Leg_WL09_Rocket_ExplosionDamage_C : USolarAbilityEffect {
};

