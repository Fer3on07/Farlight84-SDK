// BlueprintGeneratedClass BP_MassInvisibilityExEffectController.BP_MassInvisibilityExEffectController_C
// Size: 0x40 (Inherited: 0x40)
struct UBP_MassInvisibilityExEffectController_C : UTimedEffectController {
};

