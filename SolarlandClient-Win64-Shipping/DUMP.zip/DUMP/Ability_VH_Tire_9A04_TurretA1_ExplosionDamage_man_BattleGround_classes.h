// BlueprintGeneratedClass Ability_VH_Tire_9A04_TurretA1_ExplosionDamage_man_BattleGround.Ability_VH_Tire_9A04_TurretA1_ExplosionDamage_man_BattleGround_C
// Size: 0x319 (Inherited: 0x319)
struct AAbility_VH_Tire_9A04_TurretA1_ExplosionDamage_man_BattleGround_C : AAbility_VH_Tire_9A04_TurretA1_ExplosionDamage_man_C {
};

