// BlueprintGeneratedClass ChaGCBP_JetSlowFalling.ChaGCBP_JetSlowFalling_C
// Size: 0x50 (Inherited: 0x50)
struct UChaGCBP_JetSlowFalling_C : UChaGC_JetSlowFalling {
};

