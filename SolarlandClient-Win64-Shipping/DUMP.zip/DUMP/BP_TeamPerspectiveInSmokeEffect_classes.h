// BlueprintGeneratedClass BP_TeamPerspectiveInSmokeEffect.BP_TeamPerspectiveInSmokeEffect_C
// Size: 0x1c8 (Inherited: 0x1c8)
struct UBP_TeamPerspectiveInSmokeEffect_C : UMultiplePassMaterialEffect {
};

