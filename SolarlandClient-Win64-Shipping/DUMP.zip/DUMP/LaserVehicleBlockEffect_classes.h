// BlueprintGeneratedClass LaserVehicleBlockEffect.LaserVehicleBlockEffect_C
// Size: 0x848 (Inherited: 0x848)
struct ULaserVehicleBlockEffect_C : UGameplayEffect {
};

