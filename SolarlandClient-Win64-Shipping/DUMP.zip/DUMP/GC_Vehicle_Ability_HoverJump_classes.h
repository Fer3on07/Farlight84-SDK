// BlueprintGeneratedClass GC_Vehicle_Ability_HoverJump.GC_Vehicle_Ability_HoverJump_C
// Size: 0x60 (Inherited: 0x60)
struct UGC_Vehicle_Ability_HoverJump_C : USolarVehicleGC_HoverJump {
};

