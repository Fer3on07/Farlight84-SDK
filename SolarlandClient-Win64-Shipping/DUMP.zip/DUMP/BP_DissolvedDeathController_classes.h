// BlueprintGeneratedClass BP_DissolvedDeathController.BP_DissolvedDeathController_C
// Size: 0x40 (Inherited: 0x40)
struct UBP_DissolvedDeathController_C : UTimedEffectController {
};

