// BlueprintGeneratedClass ChaGCBP_SpawnExtraShield.ChaGCBP_SpawnExtraShield_C
// Size: 0x2d0 (Inherited: 0x2c8)
struct AChaGCBP_SpawnExtraShield_C : AChaGC_ExtraShield {
	struct USceneComponent* DefaultSceneRoot; // 0x2c8(0x08)
};

