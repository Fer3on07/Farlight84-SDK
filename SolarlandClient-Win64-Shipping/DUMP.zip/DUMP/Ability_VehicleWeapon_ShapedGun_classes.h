// BlueprintGeneratedClass Ability_VehicleWeapon_ShapedGun.Ability_VehicleWeapon_ShapedGun_C
// Size: 0x310 (Inherited: 0x310)
struct AAbility_VehicleWeapon_ShapedGun_C : ASolarAbility {
};

