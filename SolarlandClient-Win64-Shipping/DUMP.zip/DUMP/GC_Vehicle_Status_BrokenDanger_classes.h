// BlueprintGeneratedClass GC_Vehicle_Status_BrokenDanger.GC_Vehicle_Status_BrokenDanger_C
// Size: 0x80 (Inherited: 0x80)
struct UGC_Vehicle_Status_BrokenDanger_C : USolarVehicleGC_BrokenDanger {
};

