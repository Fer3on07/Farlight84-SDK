// BlueprintGeneratedClass BP_InWaterEffect.BP_InWaterEffect_C
// Size: 0x1c8 (Inherited: 0x1c8)
struct UBP_InWaterEffect_C : UMultiplePassMaterialEffect {
};

