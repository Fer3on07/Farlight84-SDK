// BlueprintGeneratedClass Ability_VH_Hover_WL04_StickyBomb_Explode.Ability_VH_Hover_WL04_StickyBomb_Explode_C
// Size: 0x318 (Inherited: 0x310)
struct AAbility_VH_Hover_WL04_StickyBomb_Explode_C : ASolarAbility {
	struct UParticleSystemComponent* FX_Hover_WL04_Hit; // 0x310(0x08)
};

