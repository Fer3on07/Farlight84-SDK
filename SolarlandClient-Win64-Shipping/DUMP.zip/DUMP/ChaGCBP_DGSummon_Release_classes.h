// BlueprintGeneratedClass ChaGCBP_DGSummon_Release.ChaGCBP_DGSummon_Release_C
// Size: 0x2e0 (Inherited: 0x2d8)
struct AChaGCBP_DGSummon_Release_C : AChaGC_DGSummon_MaterialUpdate {
	struct USceneComponent* DefaultSceneRoot; // 0x2d8(0x08)
};

