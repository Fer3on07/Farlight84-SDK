// BlueprintGeneratedClass BP_SolarGameSettingsRange_PC.BP_SolarGameSettingsRange_PC_C
// Size: 0x180 (Inherited: 0x180)
struct UBP_SolarGameSettingsRange_PC_C : USolarGameSettingsRange {
};

