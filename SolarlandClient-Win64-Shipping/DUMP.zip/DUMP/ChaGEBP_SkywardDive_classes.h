// BlueprintGeneratedClass ChaGEBP_SkywardDive.ChaGEBP_SkywardDive_C
// Size: 0x848 (Inherited: 0x848)
struct UChaGEBP_SkywardDive_C : UGameplayEffect {
};

