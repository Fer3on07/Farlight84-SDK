// BlueprintGeneratedClass ChaGCBP_BlindMark_Blind.ChaGCBP_BlindMark_Blind_C
// Size: 0x2b9 (Inherited: 0x2b0)
struct AChaGCBP_BlindMark_Blind_C : AChaGC_CharacterActorCueBase {
	struct USceneComponent* DefaultSceneRoot; // 0x2b0(0x08)
	bool HasSetLowPassFilter; // 0x2b8(0x01)

	bool OnRemoveInternal(struct ASolarCharacter* NullableCharacter, struct FGameplayCueParameters& Parameters); // Function ChaGCBP_BlindMark_Blind.ChaGCBP_BlindMark_Blind_C.OnRemoveInternal // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2d0f120
	bool WhileActiveInternal(struct ASolarCharacter* Character, struct FGameplayCueParameters& Parameters); // Function ChaGCBP_BlindMark_Blind.ChaGCBP_BlindMark_Blind_C.WhileActiveInternal // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2d0f120
};

