// WidgetBlueprintGeneratedClass ImageTween.ImageTween_C
// Size: 0x3d0 (Inherited: 0x3d0)
struct UImageTween_C : UTweenImage {
};

