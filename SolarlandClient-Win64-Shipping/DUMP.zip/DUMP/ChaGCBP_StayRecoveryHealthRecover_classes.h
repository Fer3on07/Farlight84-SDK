// BlueprintGeneratedClass ChaGCBP_StayRecoveryHealthRecover.ChaGCBP_StayRecoveryHealthRecover_C
// Size: 0x2b8 (Inherited: 0x2b0)
struct AChaGCBP_StayRecoveryHealthRecover_C : AChaGC_CharacterActorCueBase {
	struct USceneComponent* DefaultSceneRoot; // 0x2b0(0x08)
};

