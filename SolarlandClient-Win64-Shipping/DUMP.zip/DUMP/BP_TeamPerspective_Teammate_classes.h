// BlueprintGeneratedClass BP_TeamPerspective_Teammate.BP_TeamPerspective_Teammate_C
// Size: 0x1c8 (Inherited: 0x1c8)
struct UBP_TeamPerspective_Teammate_C : UMultiplePassMaterialEffect {
};

