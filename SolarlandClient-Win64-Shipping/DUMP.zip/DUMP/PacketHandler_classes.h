// Class PacketHandler.HandlerComponentFactory
// Size: 0x28 (Inherited: 0x28)
struct UHandlerComponentFactory : UObject {
};

// Class PacketHandler.PacketHandlerProfileConfig
// Size: 0x38 (Inherited: 0x28)
struct UPacketHandlerProfileConfig : UObject {
	struct TArray<struct FString> Components; // 0x28(0x10)
};

