// BlueprintGeneratedClass GA_CancelAllVehicleAbility.GA_CancelAllVehicleAbility_C
// Size: 0x4f0 (Inherited: 0x4f0)
struct UGA_CancelAllVehicleAbility_C : USolarVehicleGameplayAbility {
};

