// BlueprintGeneratedClass BP_LobbyGameState.BP_LobbyGameState_C
// Size: 0x308 (Inherited: 0x300)
struct ABP_LobbyGameState_C : ASolarGameStateBase {
	struct USceneComponent* DefaultSceneRoot; // 0x300(0x08)
};

