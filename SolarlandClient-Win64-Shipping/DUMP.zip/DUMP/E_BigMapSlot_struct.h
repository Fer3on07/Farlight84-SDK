// UserDefinedEnum E_BigMapSlot.E_BigMapSlot
enum class E_BigMapSlot : uint8 {
	NewEnumerator0 = 0,
	E_MAX = 1
};

