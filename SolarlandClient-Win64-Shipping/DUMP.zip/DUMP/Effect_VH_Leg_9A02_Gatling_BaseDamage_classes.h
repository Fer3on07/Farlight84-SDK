// BlueprintGeneratedClass Effect_VH_Leg_9A02_Gatling_BaseDamage.Effect_VH_Leg_9A02_Gatling_BaseDamage_C
// Size: 0x198 (Inherited: 0x198)
struct UEffect_VH_Leg_9A02_Gatling_BaseDamage_C : USolarAbilityEffect {
};

