// BlueprintGeneratedClass GCBP_LaunchCharacter.GCBP_LaunchCharacter_C
// Size: 0x2a1 (Inherited: 0x298)
struct AGCBP_LaunchCharacter_C : AGameplayCueNotify_Actor {
	struct USceneComponent* DefaultSceneRoot; // 0x298(0x08)
	bool IsSummonedJumpPad; // 0x2a0(0x01)

	bool OnActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters); // Function GCBP_LaunchCharacter.GCBP_LaunchCharacter_C.OnActive // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2d0f120
	bool OnRemove(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters); // Function GCBP_LaunchCharacter.GCBP_LaunchCharacter_C.OnRemove // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2d0f120
};

