// BlueprintGeneratedClass BP_RadarScan_MultiplePassEffect.BP_RadarScan_MultiplePassEffect_C
// Size: 0x1c8 (Inherited: 0x1c8)
struct UBP_RadarScan_MultiplePassEffect_C : UMultiplePassMaterialEffect {
};

