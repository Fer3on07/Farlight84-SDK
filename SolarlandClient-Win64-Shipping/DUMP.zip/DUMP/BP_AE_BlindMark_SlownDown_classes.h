// BlueprintGeneratedClass BP_AE_BlindMark_SlownDown.BP_AE_BlindMark_SlownDown_C
// Size: 0x1c0 (Inherited: 0x1c0)
struct UBP_AE_BlindMark_SlownDown_C : UMaterialSimpleEffect {
};

