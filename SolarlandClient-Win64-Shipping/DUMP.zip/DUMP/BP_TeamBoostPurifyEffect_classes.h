// BlueprintGeneratedClass BP_TeamBoostPurifyEffect.BP_TeamBoostPurifyEffect_C
// Size: 0x1d0 (Inherited: 0x1d0)
struct UBP_TeamBoostPurifyEffect_C : UMaterialVariableEffect {
};

