// UserDefinedEnum E_BackPackSlot.E_BackPackSlot
enum class E_BackPackSlot : uint8 {
	NewEnumerator0 = 0,
	E_MAX = 1
};

