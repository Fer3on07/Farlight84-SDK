// BlueprintGeneratedClass BP_InvisibleByZoneEffect_Teammate.BP_InvisibleByZoneEffect_Teammate_C
// Size: 0x1d0 (Inherited: 0x1d0)
struct UBP_InvisibleByZoneEffect_Teammate_C : UMaterialVariableEffect {
};

