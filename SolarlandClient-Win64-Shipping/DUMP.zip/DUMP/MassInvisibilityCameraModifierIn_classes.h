// BlueprintGeneratedClass MassInvisibilityCameraModifierIn.MassInvisibilityCameraModifierIn_C
// Size: 0x160 (Inherited: 0x160)
struct UMassInvisibilityCameraModifierIn_C : UCameraShake {
};

