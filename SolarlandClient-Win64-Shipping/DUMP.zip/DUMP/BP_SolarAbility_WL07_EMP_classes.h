// BlueprintGeneratedClass BP_SolarAbility_WL07_EMP.BP_SolarAbility_WL07_EMP_C
// Size: 0x320 (Inherited: 0x320)
struct ABP_SolarAbility_WL07_EMP_C : ASolarWeaponAbilityTemp {
};

