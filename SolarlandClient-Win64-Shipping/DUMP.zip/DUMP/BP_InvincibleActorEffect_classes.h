// BlueprintGeneratedClass BP_InvincibleActorEffect.BP_InvincibleActorEffect_C
// Size: 0x1c0 (Inherited: 0x1c0)
struct UBP_InvincibleActorEffect_C : UMaterialSimpleEffect {
};

