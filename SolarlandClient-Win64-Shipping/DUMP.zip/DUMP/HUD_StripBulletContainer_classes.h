// WidgetBlueprintGeneratedClass HUD_StripBulletContainer.HUD_StripBulletContainer_C
// Size: 0x4b8 (Inherited: 0x4b8)
struct UHUD_StripBulletContainer_C : UStripBulletContainer {
};

