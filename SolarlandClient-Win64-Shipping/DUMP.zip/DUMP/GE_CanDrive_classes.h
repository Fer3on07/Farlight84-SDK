// BlueprintGeneratedClass GE_CanDrive.GE_CanDrive_C
// Size: 0x848 (Inherited: 0x848)
struct UGE_CanDrive_C : UGameplayEffect {
};

