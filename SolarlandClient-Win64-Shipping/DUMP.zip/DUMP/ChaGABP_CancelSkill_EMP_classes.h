// BlueprintGeneratedClass ChaGABP_CancelSkill_EMP.ChaGABP_CancelSkill_EMP_C
// Size: 0x418 (Inherited: 0x418)
struct UChaGABP_CancelSkill_EMP_C : USolarGameplayAbility {
};

