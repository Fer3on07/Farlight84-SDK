// BlueprintGeneratedClass BP_9A03_QuickSummon_Forward.BP_9A03_QuickSummon_Forward_C
// Size: 0x40 (Inherited: 0x40)
struct UBP_9A03_QuickSummon_Forward_C : UBP_QuickSummon_Forward_C {
};

