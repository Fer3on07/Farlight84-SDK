// BlueprintGeneratedClass GC_SurroundLightning.GC_SurroundLightning_C
// Size: 0x300 (Inherited: 0x2f8)
struct AGC_SurroundLightning_C : ASolarSkillGC_SurroundLightning {
	struct USceneComponent* DefaultSceneRoot; // 0x2f8(0x08)
};

