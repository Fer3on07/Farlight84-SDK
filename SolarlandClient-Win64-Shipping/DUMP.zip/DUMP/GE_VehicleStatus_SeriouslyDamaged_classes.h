// BlueprintGeneratedClass GE_VehicleStatus_SeriouslyDamaged.GE_VehicleStatus_SeriouslyDamaged_C
// Size: 0x848 (Inherited: 0x848)
struct UGE_VehicleStatus_SeriouslyDamaged_C : UGameplayEffect {
};

