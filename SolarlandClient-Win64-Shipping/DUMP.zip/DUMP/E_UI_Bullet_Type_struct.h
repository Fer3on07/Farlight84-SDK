// UserDefinedEnum E_UI_Bullet_Type.E_UI_Bullet_Type
enum class E_UI_Bullet_Type : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	E_UI_Bullet_MAX = 2
};

