// BlueprintGeneratedClass ChaGCBP_AerialReconnaissanc.ChaGCBP_AerialReconnaissanc_C
// Size: 0x2c0 (Inherited: 0x2b8)
struct AChaGCBP_AerialReconnaissanc_C : AChaGC_AerialReconnaissanc {
	struct USceneComponent* DefaultSceneRoot; // 0x2b8(0x08)
};

