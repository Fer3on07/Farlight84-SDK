// BlueprintGeneratedClass Effect_VH_Tire_9A03_Rocket_ExplosionDamage_man.Effect_VH_Tire_9A03_Rocket_ExplosionDamage_man_C
// Size: 0x198 (Inherited: 0x198)
struct UEffect_VH_Tire_9A03_Rocket_ExplosionDamage_man_C : USolarAbilityEffect {
};

