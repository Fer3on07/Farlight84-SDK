// WidgetBlueprintGeneratedClass FX_Widget_Buff_AbilityIncrease.FX_Widget_Buff_AbilityIncrease_C
// Size: 0x434 (Inherited: 0x408)
struct UFX_Widget_Buff_AbilityIncrease_C : UBP_SolarScreenEffectWidget_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x408(0x08)
	struct UWidgetAnimation* Buff_AbilityIncrease; // 0x410(0x08)
	struct UImage* Left; // 0x418(0x08)
	struct UImage* Right; // 0x420(0x08)
	struct UImage* Up; // 0x428(0x08)
	float Duartion; // 0x430(0x04)

	void Construct(); // Function FX_Widget_Buff_AbilityIncrease.FX_Widget_Buff_AbilityIncrease_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2d0f120
	void ExecuteUbergraph_FX_Widget_Buff_AbilityIncrease(int32_t EntryPoint); // Function FX_Widget_Buff_AbilityIncrease.FX_Widget_Buff_AbilityIncrease_C.ExecuteUbergraph_FX_Widget_Buff_AbilityIncrease // (Final|UbergraphFunction) // @ game+0x2d0f120
};

