// BlueprintGeneratedClass BPGE_UsingContinuousSkill.BPGE_UsingContinuousSkill_C
// Size: 0x848 (Inherited: 0x848)
struct UBPGE_UsingContinuousSkill_C : UGameplayEffect {
};

