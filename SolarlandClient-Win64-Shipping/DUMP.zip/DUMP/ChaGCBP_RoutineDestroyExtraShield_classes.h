// BlueprintGeneratedClass ChaGCBP_RoutineDestroyExtraShield.ChaGCBP_RoutineDestroyExtraShield_C
// Size: 0x2d0 (Inherited: 0x2c8)
struct AChaGCBP_RoutineDestroyExtraShield_C : AChaGC_ExtraShield {
	struct USceneComponent* DefaultSceneRoot; // 0x2c8(0x08)

	bool OnExecute(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters); // Function ChaGCBP_RoutineDestroyExtraShield.ChaGCBP_RoutineDestroyExtraShield_C.OnExecute // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2d0f120
};

