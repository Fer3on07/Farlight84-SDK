// BlueprintGeneratedClass GE_VehicleStatus_Broken.GE_VehicleStatus_Broken_C
// Size: 0x848 (Inherited: 0x848)
struct UGE_VehicleStatus_Broken_C : UGameplayEffect {
};

