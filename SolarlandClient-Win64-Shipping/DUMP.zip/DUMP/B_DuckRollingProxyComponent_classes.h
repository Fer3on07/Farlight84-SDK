// BlueprintGeneratedClass B_DuckRollingProxyComponent.B_DuckRollingProxyComponent_C
// Size: 0x238 (Inherited: 0x238)
struct UB_DuckRollingProxyComponent_C : UDuckRollingProxyComponent {
};

