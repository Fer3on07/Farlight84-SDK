// BlueprintGeneratedClass Effect_VH_Tire_WL01_Flamethrower_BaseDamage.Effect_VH_Tire_WL01_Flamethrower_BaseDamage_C
// Size: 0x198 (Inherited: 0x198)
struct UEffect_VH_Tire_WL01_Flamethrower_BaseDamage_C : USolarAbilityEffect {
};

