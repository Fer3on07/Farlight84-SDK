// BlueprintGeneratedClass ChaGCBP_DuckRollingBounce.ChaGCBP_DuckRollingBounce_C
// Size: 0x2c0 (Inherited: 0x2b0)
struct AChaGCBP_DuckRollingBounce_C : AChaGC_CharacterActorCueBase {
	struct USceneComponent* DefaultSceneRoot; // 0x2b0(0x08)
	struct UParticleSystem* ParticleAsset; // 0x2b8(0x08)

	bool OnExecuteInternal(struct ASolarCharacter* Character, struct FGameplayCueParameters& Parameters); // Function ChaGCBP_DuckRollingBounce.ChaGCBP_DuckRollingBounce_C.OnExecuteInternal // (Event|Protected|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x2d0f120
};

