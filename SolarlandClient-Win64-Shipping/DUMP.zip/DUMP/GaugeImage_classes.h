// WidgetBlueprintGeneratedClass GaugeImage.GaugeImage_C
// Size: 0x2c8 (Inherited: 0x2c8)
struct UGaugeImage_C : UGaugeImage {
};

