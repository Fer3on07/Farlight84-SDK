// BlueprintGeneratedClass BP_Replay_PerspectiveInSmoke.BP_Replay_PerspectiveInSmoke_C
// Size: 0x1a8 (Inherited: 0x1a8)
struct UBP_Replay_PerspectiveInSmoke_C : USolarReplayPerspectiveInSmokeEffect {
};

