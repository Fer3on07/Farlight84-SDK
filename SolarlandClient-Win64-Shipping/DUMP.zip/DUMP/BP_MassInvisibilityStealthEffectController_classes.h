// BlueprintGeneratedClass BP_MassInvisibilityStealthEffectController.BP_MassInvisibilityStealthEffectController_C
// Size: 0x5d0 (Inherited: 0x5d0)
struct UBP_MassInvisibilityStealthEffectController_C : UMassInvisibilityEffectController {
};

