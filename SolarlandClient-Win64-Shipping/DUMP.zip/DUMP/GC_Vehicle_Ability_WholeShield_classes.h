// BlueprintGeneratedClass GC_Vehicle_Ability_WholeShield.GC_Vehicle_Ability_WholeShield_C
// Size: 0x580 (Inherited: 0x578)
struct AGC_Vehicle_Ability_WholeShield_C : AVehicleWholeShieldGCNotify_Actor {
	struct USceneComponent* DefaultSceneRoot; // 0x578(0x08)
};

