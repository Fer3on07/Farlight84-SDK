// BlueprintGeneratedClass GC_Vehicle_Ability_SeatEject.GC_Vehicle_Ability_SeatEject_C
// Size: 0x58 (Inherited: 0x50)
struct UGC_Vehicle_Ability_SeatEject_C : UGameplayCueNotify_Static {
	struct UParticleSystem* EjectParticle; // 0x50(0x08)

	bool OnActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters); // Function GC_Vehicle_Ability_SeatEject.GC_Vehicle_Ability_SeatEject_C.OnActive // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x2d0f120
};

