// BlueprintGeneratedClass GE_VHAttibute_Default.GE_VHAttibute_Default_C
// Size: 0x848 (Inherited: 0x848)
struct UGE_VHAttibute_Default_C : UGameplayEffect {
};

