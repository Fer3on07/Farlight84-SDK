// BlueprintGeneratedClass Login.Login_C
// Size: 0x230 (Inherited: 0x230)
struct ALogin_C : ALevelScriptActor {

	void ReceiveBeginPlay(); // Function Login.Login_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0xb67940
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function Login.Login_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0xb67940
	struct FString GetModuleName(); // Function Login.Login_C.GetModuleName // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x2d0f120
};

