// BlueprintGeneratedClass GE_FireworksCooldown.GE_FireworksCooldown_C
// Size: 0x848 (Inherited: 0x848)
struct UGE_FireworksCooldown_C : UGameplayEffect {
};

