// BlueprintGeneratedClass ChaGCBP_SummonTower_Release.ChaGCBP_SummonTower_Release_C
// Size: 0x2b8 (Inherited: 0x2b0)
struct AChaGCBP_SummonTower_Release_C : AChaGC_CharacterActorCueBase {
	struct USceneComponent* DefaultSceneRoot; // 0x2b0(0x08)
};

