// BlueprintGeneratedClass ChaGABP_Fire.ChaGABP_Fire_C
// Size: 0x470 (Inherited: 0x470)
struct UChaGABP_Fire_C : UChaGA_Fire {
};

