// BlueprintGeneratedClass GC_Vehicle_Ability_ToggleStealth.GC_Vehicle_Ability_ToggleStealth_C
// Size: 0x558 (Inherited: 0x550)
struct AGC_Vehicle_Ability_ToggleStealth_C : AVehicleStealthGCNotify_Actor {
	struct USceneComponent* DefaultSceneRoot; // 0x550(0x08)
};

