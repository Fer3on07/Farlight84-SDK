// BlueprintGeneratedClass BP_WAT_RocketLauncher.BP_WAT_RocketLauncher_C
// Size: 0x100 (Inherited: 0x100)
struct UBP_WAT_RocketLauncher_C : USolarWeaponAT_FireRocket {
};

