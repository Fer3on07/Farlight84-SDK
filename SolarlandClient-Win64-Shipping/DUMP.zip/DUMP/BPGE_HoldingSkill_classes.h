// BlueprintGeneratedClass BPGE_HoldingSkill.BPGE_HoldingSkill_C
// Size: 0x848 (Inherited: 0x848)
struct UBPGE_HoldingSkill_C : UGameplayEffect {
};

