// BlueprintGeneratedClass GC_Vehicle_Ability_EquipWeapon.GC_Vehicle_Ability_EquipWeapon_C
// Size: 0x50 (Inherited: 0x50)
struct UGC_Vehicle_Ability_EquipWeapon_C : USolarVehicleGC_EquipWeapon {
};

