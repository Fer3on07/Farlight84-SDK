// BlueprintGeneratedClass ChaGABP_Bolt.ChaGABP_Bolt_C
// Size: 0x468 (Inherited: 0x468)
struct UChaGABP_Bolt_C : UChaGA_Bolt {
};

