// BlueprintGeneratedClass ChaGCBP_MassInvisibilityRange.ChaGCBP_MassInvisibilityRange_C
// Size: 0x50 (Inherited: 0x50)
struct UChaGCBP_MassInvisibilityRange_C : UGameplayCueNotify_Static {

	bool OnExecute(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters); // Function ChaGCBP_MassInvisibilityRange.ChaGCBP_MassInvisibilityRange_C.OnExecute // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x2d0f120
};

