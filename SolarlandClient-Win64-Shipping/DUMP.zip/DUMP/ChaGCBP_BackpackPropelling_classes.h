// BlueprintGeneratedClass ChaGCBP_BackpackPropelling.ChaGCBP_BackpackPropelling_C
// Size: 0x58 (Inherited: 0x58)
struct UChaGCBP_BackpackPropelling_C : UChaGC_BackpackPropelling {
};

