// BlueprintGeneratedClass BP_BlackHole_Outline.BP_BlackHole_Outline_C
// Size: 0x1c8 (Inherited: 0x1c8)
struct UBP_BlackHole_Outline_C : UMultiplePassMaterialEffect {
};

