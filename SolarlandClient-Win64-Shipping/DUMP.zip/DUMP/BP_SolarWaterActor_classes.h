// BlueprintGeneratedClass BP_SolarWaterActor.BP_SolarWaterActor_C
// Size: 0x590 (Inherited: 0x590)
struct ABP_SolarWaterActor_C : ASolarWaterActorNew {
};

