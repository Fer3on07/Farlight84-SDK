// BlueprintGeneratedClass GE_VehicleStatus_Damaged.GE_VehicleStatus_Damaged_C
// Size: 0x848 (Inherited: 0x848)
struct UGE_VehicleStatus_Damaged_C : UGameplayEffect {
};

