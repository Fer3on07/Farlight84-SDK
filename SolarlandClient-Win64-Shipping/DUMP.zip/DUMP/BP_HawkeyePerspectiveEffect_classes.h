// BlueprintGeneratedClass BP_HawkeyePerspectiveEffect.BP_HawkeyePerspectiveEffect_C
// Size: 0x1c8 (Inherited: 0x1c8)
struct UBP_HawkeyePerspectiveEffect_C : UMultiplePassMaterialEffect {
};

