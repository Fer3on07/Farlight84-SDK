// BlueprintGeneratedClass BP_RollingDuckShiledComponent.BP_RollingDuckShiledComponent_C
// Size: 0x640 (Inherited: 0x640)
struct UBP_RollingDuckShiledComponent_C : UStaticMeshComponent {
};

