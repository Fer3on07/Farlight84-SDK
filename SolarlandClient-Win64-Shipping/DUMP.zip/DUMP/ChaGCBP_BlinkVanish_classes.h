// BlueprintGeneratedClass ChaGCBP_BlinkVanish.ChaGCBP_BlinkVanish_C
// Size: 0x88 (Inherited: 0x88)
struct UChaGCBP_BlinkVanish_C : UChaGC_BlinkVanish {
};

