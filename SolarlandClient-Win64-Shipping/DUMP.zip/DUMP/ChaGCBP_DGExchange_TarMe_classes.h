// BlueprintGeneratedClass ChaGCBP_DGExchange_TarMe.ChaGCBP_DGExchange_TarMe_C
// Size: 0x2b8 (Inherited: 0x2b0)
struct AChaGCBP_DGExchange_TarMe_C : AChaGC_CharacterActorCueBase {
	struct USceneComponent* DefaultSceneRoot; // 0x2b0(0x08)
};

