// BlueprintGeneratedClass GE_VH_WL05_Attribute_Default.GE_VH_WL05_Attribute_Default_C
// Size: 0x848 (Inherited: 0x848)
struct UGE_VH_WL05_Attribute_Default_C : UGameplayEffect {
};

