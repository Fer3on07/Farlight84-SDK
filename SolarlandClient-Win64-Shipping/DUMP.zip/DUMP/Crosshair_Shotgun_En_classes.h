// WidgetBlueprintGeneratedClass Crosshair_Shotgun_En.Crosshair_Shotgun_En_C
// Size: 0x314 (Inherited: 0x300)
struct UCrosshair_Shotgun_En_C : UCrossHairWidget {
	struct UOverlay* SpreadImg_left; // 0x300(0x08)
	struct UOverlay* SpreadImg_Right; // 0x308(0x08)
	int32_t   ; // 0x310(0x04)
};

