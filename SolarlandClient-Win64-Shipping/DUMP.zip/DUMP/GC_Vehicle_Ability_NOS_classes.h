// BlueprintGeneratedClass GC_Vehicle_Ability_NOS.GC_Vehicle_Ability_NOS_C
// Size: 0x2a8 (Inherited: 0x2a0)
struct AGC_Vehicle_Ability_NOS_C : ASolarVehicleNosGCNotify_Actor {
	struct USceneComponent* DefaultSceneRoot; // 0x2a0(0x08)
};

