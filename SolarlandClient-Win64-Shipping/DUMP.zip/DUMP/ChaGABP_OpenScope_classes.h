// BlueprintGeneratedClass ChaGABP_OpenScope.ChaGABP_OpenScope_C
// Size: 0x4c8 (Inherited: 0x4c8)
struct UChaGABP_OpenScope_C : UChaGA_OpenScope {
};

