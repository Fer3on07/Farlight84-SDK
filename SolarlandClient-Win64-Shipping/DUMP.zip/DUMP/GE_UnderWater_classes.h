// BlueprintGeneratedClass GE_UnderWater.GE_UnderWater_C
// Size: 0x848 (Inherited: 0x848)
struct UGE_UnderWater_C : UGameplayEffect {
};

