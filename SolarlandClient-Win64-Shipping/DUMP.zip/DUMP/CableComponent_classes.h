// Class CableComponent.CableActor
// Size: 0x230 (Inherited: 0x228)
struct ACableActor : AActor {
	struct UCableComponent* CableComponent; // 0x228(0x08)
};

// Class CableComponent.CableComponent
// Size: 0x640 (Inherited: 0x5b0)
struct UCableComponent : UMeshComponent {
	bool bAttachStart; // 0x5b0(0x01)
	bool bAttachEnd; // 0x5b1(0x01)
	char pad_5B2[0x6]; // 0x5b2(0x06)
	struct FComponentReference AttachEndTo; // 0x5b8(0x28)
	struct FName AttachEndToSocketName; // 0x5e0(0x08)
	struct FVector EndLocation; // 0x5e8(0x0c)
	float CableLength; // 0x5f4(0x04)
	int32_t NumSegments; // 0x5f8(0x04)
	float SubstepTime; // 0x5fc(0x04)
	int32_t SolverIterations; // 0x600(0x04)
	bool bEnableStiffness; // 0x604(0x01)
	bool bEnableCollision; // 0x605(0x01)
	char pad_606[0x2]; // 0x606(0x02)
	float CollisionFriction; // 0x608(0x04)
	struct FVector CableForce; // 0x60c(0x0c)
	float CableGravityScale; // 0x618(0x04)
	float CableWidth; // 0x61c(0x04)
	int32_t NumSides; // 0x620(0x04)
	float TileMaterial; // 0x624(0x04)
	char pad_628[0x18]; // 0x628(0x18)

	void SetAttachEndToComponent(struct USceneComponent* Component, struct FName SocketName); // Function CableComponent.CableComponent.SetAttachEndToComponent // (Final|Native|Public|BlueprintCallable) // @ game+0x1d324b0
	void SetAttachEndTo(struct AActor* Actor, struct FName ComponentProperty, struct FName SocketName); // Function CableComponent.CableComponent.SetAttachEndTo // (Final|Native|Public|BlueprintCallable) // @ game+0x1d323a0
	void GetCableParticleLocations(struct TArray<struct FVector>& Locations); // Function CableComponent.CableComponent.GetCableParticleLocations // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x1d322f0
	struct USceneComponent* GetAttachedComponent(); // Function CableComponent.CableComponent.GetAttachedComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1d322c0
	struct AActor* GetAttachedActor(); // Function CableComponent.CableComponent.GetAttachedActor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x1d32290
};

