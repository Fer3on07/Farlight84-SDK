// Class RichtapToolsLib.RichtapClip
// Size: 0x50 (Inherited: 0x28)
struct URichtapClip : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FString ClipData; // 0x30(0x10)
	char pad_40[0x10]; // 0x40(0x10)
};

