// BlueprintGeneratedClass BP_AE_BlindMark_SlowDown_Mp.BP_AE_BlindMark_SlowDown_Mp_C
// Size: 0x1c8 (Inherited: 0x1c8)
struct UBP_AE_BlindMark_SlowDown_Mp_C : UMultiplePassMaterialEffect {
};

