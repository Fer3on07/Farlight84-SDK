// BlueprintGeneratedClass Ability_VH_Hover_WL04_StickyBomb_Explode_BattleGround.Ability_VH_Hover_WL04_StickyBomb_Explode_BattleGround_C
// Size: 0x318 (Inherited: 0x318)
struct AAbility_VH_Hover_WL04_StickyBomb_Explode_BattleGround_C : AAbility_VH_Hover_WL04_StickyBomb_Explode_C {
};

