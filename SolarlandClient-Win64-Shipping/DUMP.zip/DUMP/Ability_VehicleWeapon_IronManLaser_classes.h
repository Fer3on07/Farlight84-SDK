// BlueprintGeneratedClass Ability_VehicleWeapon_IronManLaser.Ability_VehicleWeapon_IronManLaser_C
// Size: 0x310 (Inherited: 0x310)
struct AAbility_VehicleWeapon_IronManLaser_C : ASolarAbility {
};

