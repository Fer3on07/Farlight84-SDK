// BlueprintGeneratedClass BP_WheeledVehicleBase.BP_WheeledVehicleBase_C
// Size: 0x13f0 (Inherited: 0x13f0)
struct ABP_WheeledVehicleBase_C : ASolarWheeledVehicle {
};

