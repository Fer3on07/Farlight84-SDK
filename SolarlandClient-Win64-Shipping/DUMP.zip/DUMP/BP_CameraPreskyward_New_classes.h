// BlueprintGeneratedClass BP_CameraPreskyward_New.BP_CameraPreskyward_New_C
// Size: 0x180 (Inherited: 0x180)
struct UBP_CameraPreskyward_New_C : USolarCameraShake {
};

