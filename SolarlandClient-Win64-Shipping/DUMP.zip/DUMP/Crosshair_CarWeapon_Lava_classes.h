// WidgetBlueprintGeneratedClass Crosshair_CarWeapon_Lava.Crosshair_CarWeapon_Lava_C
// Size: 0x490 (Inherited: 0x488)
struct UCrosshair_CarWeapon_Lava_C : UVehicleWeaponCrossHairWidget {
	struct UImage* SpreadImg_coredot; // 0x488(0x08)

	void SetWidgetResources(struct UCanvasPanel*& InSecondReticlePanel, struct UImage*& InReticleDirectionImage, struct UImage*& InRangedImage, struct USizeBox*& InAssistLockSizeBox, struct UCanvasPanel*& InChangeNewAssistLockPawnPanel, struct UCanvasPanel*& InEnterLockPawnPanel, struct UCanvasPanel*& InCanvas_Dynamic); // Function Crosshair_CarWeapon_Lava.Crosshair_CarWeapon_Lava_C.SetWidgetResources // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2d0f120
};

