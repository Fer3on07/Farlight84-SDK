// BlueprintGeneratedClass ChaGCBP_WallRun.ChaGCBP_WallRun_C
// Size: 0x50 (Inherited: 0x50)
struct UChaGCBP_WallRun_C : UChaGC_WallRun {
};

