// BlueprintGeneratedClass BP_SolarRuntimeAssetsCollection.BP_SolarRuntimeAssetsCollection_C
// Size: 0x38 (Inherited: 0x38)
struct UBP_SolarRuntimeAssetsCollection_C : USolarRuntimeAssetsCollection {
};

