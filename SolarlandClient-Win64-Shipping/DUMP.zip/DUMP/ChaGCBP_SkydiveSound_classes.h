// BlueprintGeneratedClass ChaGCBP_SkydiveSound.ChaGCBP_SkydiveSound_C
// Size: 0x2c0 (Inherited: 0x2b8)
struct AChaGCBP_SkydiveSound_C : AChaGC_SkydiveSound {
	struct USceneComponent* DefaultSceneRoot; // 0x2b8(0x08)
};

