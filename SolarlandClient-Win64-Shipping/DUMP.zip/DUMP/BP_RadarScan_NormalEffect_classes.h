// BlueprintGeneratedClass BP_RadarScan_NormalEffect.BP_RadarScan_NormalEffect_C
// Size: 0x1c0 (Inherited: 0x1c0)
struct UBP_RadarScan_NormalEffect_C : UMaterialSimpleEffect {
};

