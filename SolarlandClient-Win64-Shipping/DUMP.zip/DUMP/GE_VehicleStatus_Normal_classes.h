// BlueprintGeneratedClass GE_VehicleStatus_Normal.GE_VehicleStatus_Normal_C
// Size: 0x848 (Inherited: 0x848)
struct UGE_VehicleStatus_Normal_C : UGameplayEffect {
};

