// BlueprintGeneratedClass GC_Vehicle_Status_Damaged.GC_Vehicle_Status_Damaged_C
// Size: 0x50 (Inherited: 0x50)
struct UGC_Vehicle_Status_Damaged_C : UGameplayCueNotify_Static {

	bool WhileActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters); // Function GC_Vehicle_Status_Damaged.GC_Vehicle_Status_Damaged_C.WhileActive // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x2d0f120
	bool OnRemove(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters); // Function GC_Vehicle_Status_Damaged.GC_Vehicle_Status_Damaged_C.OnRemove // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x2d0f120
};

