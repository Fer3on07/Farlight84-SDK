// BlueprintGeneratedClass BP_Replay_Perspective.BP_Replay_Perspective_C
// Size: 0x1a8 (Inherited: 0x1a8)
struct UBP_Replay_Perspective_C : USolarReplayPerspectiveEffect {
};

