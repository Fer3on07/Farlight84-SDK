// BlueprintGeneratedClass BP_WL09_QuickSummon_Forward.BP_WL09_QuickSummon_Forward_C
// Size: 0x40 (Inherited: 0x40)
struct UBP_WL09_QuickSummon_Forward_C : UBP_QuickSummon_Forward_C {
};

