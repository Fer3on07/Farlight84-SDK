// BlueprintGeneratedClass ChaGCBP_CombatRegeneration.ChaGCBP_CombatRegeneration_C
// Size: 0x50 (Inherited: 0x50)
struct UChaGCBP_CombatRegeneration_C : UGameplayCueNotify_Static {

	bool OnExecute(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters); // Function ChaGCBP_CombatRegeneration.ChaGCBP_CombatRegeneration_C.OnExecute // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x2d0f120
};

