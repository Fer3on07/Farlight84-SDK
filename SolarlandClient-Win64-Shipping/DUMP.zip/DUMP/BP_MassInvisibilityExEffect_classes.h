// BlueprintGeneratedClass BP_MassInvisibilityExEffect.BP_MassInvisibilityExEffect_C
// Size: 0x1d0 (Inherited: 0x1d0)
struct UBP_MassInvisibilityExEffect_C : UMaterialVariableEffect {
};

