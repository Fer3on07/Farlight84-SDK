// BlueprintGeneratedClass Effect_VH_Tire_Mphy01_TurretA1_BaseDamage.Effect_VH_Tire_Mphy01_TurretA1_BaseDamage_C
// Size: 0x198 (Inherited: 0x198)
struct UEffect_VH_Tire_Mphy01_TurretA1_BaseDamage_C : USolarAbilityEffect {
};

