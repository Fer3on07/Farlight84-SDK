// BlueprintGeneratedClass ChaGEBP_SlowDown.ChaGEBP_SlowDown_C
// Size: 0x848 (Inherited: 0x848)
struct UChaGEBP_SlowDown_C : UGameplayEffect {
};

