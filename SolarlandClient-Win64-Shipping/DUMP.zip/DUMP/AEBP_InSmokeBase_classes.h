// BlueprintGeneratedClass AEBP_InSmokeBase.AEBP_InSmokeBase_C
// Size: 0x1c8 (Inherited: 0x1c8)
struct UAEBP_InSmokeBase_C : UMultiplePassMaterialEffect {
};

