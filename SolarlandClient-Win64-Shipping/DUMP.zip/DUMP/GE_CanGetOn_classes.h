// BlueprintGeneratedClass GE_CanGetOn.GE_CanGetOn_C
// Size: 0x848 (Inherited: 0x848)
struct UGE_CanGetOn_C : UGameplayEffect {
};

