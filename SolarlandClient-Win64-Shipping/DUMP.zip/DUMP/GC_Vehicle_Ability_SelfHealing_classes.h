// BlueprintGeneratedClass GC_Vehicle_Ability_SelfHealing.GC_Vehicle_Ability_SelfHealing_C
// Size: 0xb0 (Inherited: 0xb0)
struct UGC_Vehicle_Ability_SelfHealing_C : USelfHealingCueNotify_Static {
};

