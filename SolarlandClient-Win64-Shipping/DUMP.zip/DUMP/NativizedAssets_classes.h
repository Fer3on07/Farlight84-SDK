// Class NativizedAssets.__Delegates__ABP_Penguin_C__pf944487101
// Size: 0x28 (Inherited: 0x28)
struct U__Delegates__ABP_Penguin_C__pf944487101 : UObject {
};

