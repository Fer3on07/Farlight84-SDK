// BlueprintGeneratedClass GA_Weapon_EMP_Throw.GA_Weapon_EMP_Throw_C
// Size: 0x430 (Inherited: 0x428)
struct UGA_Weapon_EMP_Throw_C : USolarWeaponGameplayAbility {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x428(0x08)

	void K2_ActivateAbilityFromEvent(struct FGameplayEventData& EventData); // Function GA_Weapon_EMP_Throw.GA_Weapon_EMP_Throw_C.K2_ActivateAbilityFromEvent // (Event|Protected|HasOutParms|BlueprintEvent) // @ game+0x2d0f120
	void ExecuteUbergraph_GA_Weapon_EMP_Throw(int32_t EntryPoint); // Function GA_Weapon_EMP_Throw.GA_Weapon_EMP_Throw_C.ExecuteUbergraph_GA_Weapon_EMP_Throw // (Final|UbergraphFunction|HasDefaults) // @ game+0x2d0f120
};

